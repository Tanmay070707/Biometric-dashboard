import { useState, useMemo } from 'react';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { mockData, generateMockData } from '@/data/mockData';
import { 
  aggregateByState, 
  aggregateByDistrict,
  calculateMetrics
} from '@/lib/analytics';
import { Header } from '@/components/dashboard/Header';
import { KPIRow } from '@/components/dashboard/KPIRow';
import { GeoHeatmap } from '@/components/dashboard/GeoHeatmap';
import { StateADRChart } from '@/components/dashboard/StateADRChart';

const GeoIntelligence = () => {
  const [data, setData] = useState(mockData);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const stateData = useMemo(() => aggregateByState(data), [data]);
  const districtData = useMemo(() => aggregateByDistrict(data), [data]);
  const metrics = useMemo(() => calculateMetrics(data), [data]);

  const meanDailyVolume = useMemo(() => {
    const uniqueDates = new Set(data.map(d => d.date)).size;
    return Math.round(metrics.totalTransactions / uniqueDates);
  }, [data, metrics.totalTransactions]);

  const handleRefresh = () => {
    setData(generateMockData());
    setLastUpdated(new Date());
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        lastUpdated={lastUpdated}
        alertCount={0}
        onRefresh={handleRefresh}
      />

      <main className="container mx-auto px-4 py-6">
        {/* Back navigation */}
        <Link 
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Dashboard
        </Link>

        <div className="mb-6">
          <h1 className="text-2xl font-bold">Geo Intelligence</h1>
          <p className="text-muted-foreground">State and district-level biometric insights</p>
        </div>

        {/* KPI Row */}
        <KPIRow metrics={metrics} meanDailyVolume={meanDailyVolume} />

        {/* State ADR Chart */}
        <div className="mb-6">
          <StateADRChart data={stateData} />
        </div>

        {/* Geo Heatmap */}
        <GeoHeatmap stateData={stateData} districtData={districtData} />
      </main>
    </div>
  );
};

export default GeoIntelligence;
