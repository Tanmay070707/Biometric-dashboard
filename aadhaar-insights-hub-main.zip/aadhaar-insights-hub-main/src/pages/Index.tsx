import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import { mockData, generateMockData } from '@/data/mockData';
import { 
  aggregateByDate, 
  aggregateByState, 
  aggregateByDistrict,
  calculateMetrics,
  generateRecommendations 
} from '@/lib/analytics';
import { Header } from '@/components/dashboard/Header';
import { KPIRow } from '@/components/dashboard/KPIRow';
import { TrendChart } from '@/components/dashboard/TrendChart';
import { StateADRChart } from '@/components/dashboard/StateADRChart';
import { DistrictTable } from '@/components/dashboard/DistrictTable';
import { ActionEngine } from '@/components/dashboard/ActionEngine';
import { ADRGauge } from '@/components/dashboard/ADRGauge';
import { AGSIndicator } from '@/components/dashboard/AGSIndicator';

const Index = () => {
  const [data, setData] = useState(mockData);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const dailyData = useMemo(() => aggregateByDate(data), [data]);
  const stateData = useMemo(() => aggregateByState(data), [data]);
  const districtData = useMemo(() => aggregateByDistrict(data), [data]);
  const metrics = useMemo(() => calculateMetrics(data), [data]);
  const recommendations = useMemo(() => generateRecommendations(data), [data]);

  const meanDailyVolume = useMemo(() => {
    const uniqueDates = new Set(data.map(d => d.date)).size;
    return Math.round(metrics.totalTransactions / uniqueDates);
  }, [data, metrics.totalTransactions]);

  const spikeDetected = useMemo(() => metrics.anomalyCount > 0, [metrics.anomalyCount]);

  const handleRefresh = () => {
    setData(generateMockData());
    setLastUpdated(new Date());
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        lastUpdated={lastUpdated}
        alertCount={recommendations.filter(r => r.severity === 'danger').length}
        onRefresh={handleRefresh}
      />

      <main className="container mx-auto px-4 py-6">
        {/* Navigation to Geo Intelligence */}
        <div className="flex justify-end mb-4">
          <Link 
            to="/geo"
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
          >
            <MapPin className="h-4 w-4" />
            Geo Intelligence
          </Link>
        </div>

        {/* 1️⃣ Top KPI Row - ADR, AGS, Mean Day, Spike Days */}
        <KPIRow metrics={metrics} meanDailyVolume={meanDailyVolume} />

        {/* Main content grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Left column - Charts */}
          <div className="lg:col-span-2 space-y-6">
            {/* 2️⃣ Daily Trend + Threshold */}
            <TrendChart data={dailyData} threshold={metrics.spikeThreshold} />
            
            {/* 3️⃣ State ADR Chart */}
            <StateADRChart data={stateData} />
          </div>

          {/* Right column - Action Engine & Gauges */}
          <div className="space-y-6">
            {/* 4️⃣ Action Engine Box */}
            <ActionEngine metrics={metrics} spikeDetected={spikeDetected} />
            
            <ADRGauge value={metrics.averageADR} />
            <AGSIndicator value={metrics.accessGapScore} />
          </div>
        </div>

        {/* Bottom section - District Table */}
        <DistrictTable data={districtData} limit={10} />

        {/* Footer info */}
        <footer className="mt-8 text-center text-xs text-muted-foreground py-4 border-t border-border">
          <p>
            Data Pipeline: Raw Data → Metrics Calculation → Anomaly Detection → Action Recommendations
          </p>
          <p className="mt-1">
            Thresholds: ADR &gt; 55% → IRIS/FACE | Spike Detected → Mobile Van | AGS &gt; 6% → New Center
          </p>
        </footer>
      </main>
    </div>
  );
};

export default Index;
