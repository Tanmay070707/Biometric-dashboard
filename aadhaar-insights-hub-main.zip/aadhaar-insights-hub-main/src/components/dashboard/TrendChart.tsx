import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart,
  Scatter
} from 'recharts';
import { DailyAggregate } from '@/types/biometric';

interface TrendChartProps {
  data: DailyAggregate[];
  threshold: number;
}

export function TrendChart({ data, threshold }: TrendChartProps) {
  const formatDate = (date: string) => {
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const formatValue = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toString();
  };

  const chartData = data.map(d => ({
    ...d,
    formattedDate: formatDate(d.date),
    anomalyPoint: d.isAnomaly ? d.total : null,
  }));

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Daily Transaction Volume</h3>
          <p className="text-sm text-muted-foreground">
            Anomaly detection using μ + 2σ method
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-muted-foreground">Normal</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-destructive" />
            <span className="text-muted-foreground">Anomaly</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-0.5 border-t-2 border-dashed border-warning" />
            <span className="text-muted-foreground">Threshold</span>
          </div>
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height={300}>
        <ComposedChart data={chartData} margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
          <defs>
            <linearGradient id="colorVolume" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(173, 80%, 40%)" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="hsl(173, 80%, 40%)" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(217, 33%, 22%)" vertical={false} />
          <XAxis 
            dataKey="formattedDate" 
            stroke="hsl(215, 20%, 65%)"
            fontSize={11}
            tickLine={false}
            axisLine={false}
          />
          <YAxis 
            stroke="hsl(215, 20%, 65%)"
            fontSize={11}
            tickFormatter={formatValue}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'hsl(222, 47%, 14%)',
              border: '1px solid hsl(217, 33%, 22%)',
              borderRadius: '8px',
              fontSize: '12px',
            }}
            labelStyle={{ color: 'hsl(210, 40%, 98%)' }}
            formatter={(value: number, name: string) => [
              formatValue(value),
              name === 'total' ? 'Total Volume' : name
            ]}
          />
          <ReferenceLine 
            y={threshold} 
            stroke="hsl(38, 92%, 50%)" 
            strokeDasharray="5 5"
            label={{
              value: `Threshold: ${formatValue(threshold)}`,
              position: 'right',
              fill: 'hsl(38, 92%, 50%)',
              fontSize: 10,
            }}
          />
          <Area
            type="monotone"
            dataKey="total"
            stroke="hsl(173, 80%, 40%)"
            strokeWidth={2}
            fill="url(#colorVolume)"
          />
          <Scatter
            dataKey="anomalyPoint"
            fill="hsl(0, 84%, 60%)"
            shape={(props: any) => {
              if (!props.payload.anomalyPoint) return null;
              return (
                <circle
                  cx={props.cx}
                  cy={props.cy}
                  r={6}
                  fill="hsl(0, 84%, 60%)"
                  stroke="hsl(0, 84%, 70%)"
                  strokeWidth={2}
                />
              );
            }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
