import { StateAggregate } from '@/types/biometric';
import { cn } from '@/lib/utils';

interface StateHeatmapProps {
  data: StateAggregate[];
}

export function StateHeatmap({ data }: StateHeatmapProps) {
  const maxTotal = Math.max(...data.map(d => d.total));
  
  const getIntensity = (total: number): string => {
    const ratio = total / maxTotal;
    if (ratio > 0.8) return 'bg-primary';
    if (ratio > 0.6) return 'bg-primary/80';
    if (ratio > 0.4) return 'bg-primary/60';
    if (ratio > 0.2) return 'bg-primary/40';
    return 'bg-primary/20';
  };

  const formatValue = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toString();
  };

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="mb-4">
        <h3 className="text-lg font-semibold">State-wise Distribution</h3>
        <p className="text-sm text-muted-foreground">
          Biometric transaction load by state
        </p>
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {data.map((state) => (
          <div
            key={state.state}
            className={cn(
              "heatmap-cell relative rounded-lg p-4 cursor-pointer group",
              getIntensity(state.total)
            )}
          >
            <div className="relative z-10">
              <p className="text-xs font-medium text-primary-foreground/90 truncate">
                {state.state}
              </p>
              <p className="text-lg font-bold text-primary-foreground mt-1">
                {formatValue(state.total)}
              </p>
              <p className="text-xs text-primary-foreground/70">
                ADR: {(state.adr * 100).toFixed(1)}%
              </p>
            </div>
            
            {/* Hover tooltip */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-card border border-border rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20 whitespace-nowrap">
              <p className="text-xs font-medium">{state.state}</p>
              <p className="text-xs text-muted-foreground">
                Districts: {state.districtCount}
              </p>
              <p className="text-xs text-muted-foreground">
                Youth: {formatValue(state.bio_age_5_17)}
              </p>
              <p className="text-xs text-muted-foreground">
                Adult: {formatValue(state.bio_age_17_)}
              </p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Legend */}
      <div className="flex items-center justify-center gap-2 mt-4 text-xs text-muted-foreground">
        <span>Low</span>
        <div className="flex gap-1">
          <div className="w-6 h-3 rounded bg-primary/20" />
          <div className="w-6 h-3 rounded bg-primary/40" />
          <div className="w-6 h-3 rounded bg-primary/60" />
          <div className="w-6 h-3 rounded bg-primary/80" />
          <div className="w-6 h-3 rounded bg-primary" />
        </div>
        <span>High</span>
      </div>
    </div>
  );
}
