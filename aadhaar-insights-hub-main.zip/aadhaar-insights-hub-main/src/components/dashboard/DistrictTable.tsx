import { DistrictAggregate } from '@/types/biometric';
import { cn } from '@/lib/utils';
import { AlertTriangle, TrendingUp } from 'lucide-react';

interface DistrictTableProps {
  data: DistrictAggregate[];
  limit?: number;
}

export function DistrictTable({ data, limit = 10 }: DistrictTableProps) {
  const displayData = data.slice(0, limit);
  const maxTotal = Math.max(...data.map(d => d.total));

  const formatValue = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(2)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toString();
  };

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Top Districts by Load</h3>
          <p className="text-sm text-muted-foreground">
            Highest volume enrollment centers
          </p>
        </div>
        <div className="flex items-center gap-1 text-xs text-warning">
          <AlertTriangle className="h-3 w-3" />
          <span>High ADR (&gt;55%)</span>
        </div>
      </div>

      <div className="space-y-2">
        {displayData.map((district, index) => {
          const progressWidth = (district.total / maxTotal) * 100;
          const isHighADR = district.adr > 0.55;
          
          return (
            <div
              key={`${district.state}-${district.district}`}
              className="relative rounded-lg bg-muted/30 overflow-hidden"
            >
              {/* Progress bar background */}
              <div 
                className={cn(
                  "absolute inset-y-0 left-0 transition-all duration-500",
                  isHighADR ? "bg-warning/20" : "bg-primary/20"
                )}
                style={{ width: `${progressWidth}%` }}
              />
              
              <div className="relative flex items-center justify-between p-3">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-muted-foreground w-5">
                    #{index + 1}
                  </span>
                  <div>
                    <p className="font-medium text-sm">{district.district}</p>
                    <p className="text-xs text-muted-foreground">{district.state}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="font-mono text-sm font-semibold">
                      {formatValue(district.total)}
                    </p>
                    <p className="text-xs text-muted-foreground">transactions</p>
                  </div>
                  
                  <div className={cn(
                    "flex items-center gap-1 px-2 py-1 rounded text-xs font-medium",
                    isHighADR 
                      ? "bg-warning/20 text-warning" 
                      : "bg-success/20 text-success"
                  )}>
                    {isHighADR && <TrendingUp className="h-3 w-3" />}
                    <span>{(district.adr * 100).toFixed(1)}%</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
