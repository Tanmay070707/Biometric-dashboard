import { AlertCircle, Eye, Truck, Building2, CheckCircle2 } from 'lucide-react';
import { Metrics } from '@/types/biometric';
import { cn } from '@/lib/utils';

interface ActionEngineProps {
  metrics: Metrics;
  spikeDetected: boolean;
}

interface ActionRule {
  condition: boolean;
  icon: React.ReactNode;
  label: string;
  action: string;
  severity: 'danger' | 'warning' | 'info' | 'success';
}

export function ActionEngine({ metrics, spikeDetected }: ActionEngineProps) {
  const rules: ActionRule[] = [
    {
      condition: metrics.averageADR > 0.55,
      icon: <Eye className="h-4 w-4" />,
      label: 'ADR High',
      action: 'Enable IRIS/FACE counters',
      severity: metrics.averageADR > 0.65 ? 'danger' : 'warning',
    },
    {
      condition: spikeDetected,
      icon: <Truck className="h-4 w-4" />,
      label: 'Spike Detected',
      action: 'Deploy Mobile Van',
      severity: 'danger',
    },
    {
      condition: metrics.accessGapScore > 0.06,
      icon: <Building2 className="h-4 w-4" />,
      label: 'AGS High',
      action: 'Suggest New Center',
      severity: 'warning',
    },
    {
      condition: metrics.anomalyCount > 3,
      icon: <AlertCircle className="h-4 w-4" />,
      label: 'Multiple Anomalies',
      action: 'Enable Appointments',
      severity: 'danger',
    },
  ];

  const activeRules = rules.filter(r => r.condition);
  const allClear = activeRules.length === 0;

  const severityStyles = {
    danger: 'bg-destructive/20 text-destructive border-destructive/30',
    warning: 'bg-warning/20 text-warning border-warning/30',
    info: 'bg-primary/20 text-primary border-primary/30',
    success: 'bg-success/20 text-success border-success/30',
  };

  const dotStyles = {
    danger: 'bg-destructive',
    warning: 'bg-warning',
    info: 'bg-primary',
    success: 'bg-success',
  };

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Action Engine</h3>
          <p className="text-sm text-muted-foreground">
            Automated decision triggers
          </p>
        </div>
        {!allClear && (
          <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-destructive/20">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-destructive"></span>
            </span>
            <span className="text-xs font-medium text-destructive">{activeRules.length} Active</span>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {allClear ? (
          <div className="flex items-center gap-3 p-4 rounded-lg bg-success/10 border border-success/20">
            <CheckCircle2 className="h-5 w-5 text-success" />
            <div>
              <p className="text-sm font-medium text-success">All Systems Normal</p>
              <p className="text-xs text-muted-foreground">No action required</p>
            </div>
          </div>
        ) : (
          activeRules.map((rule, index) => (
            <div 
              key={index}
              className={cn(
                "flex items-center gap-3 p-3 rounded-lg border transition-all hover:scale-[1.02]",
                severityStyles[rule.severity]
              )}
            >
              <div className={cn("p-2 rounded-lg", severityStyles[rule.severity])}>
                {rule.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className={cn("w-2 h-2 rounded-full", dotStyles[rule.severity])} />
                  <span className="text-sm font-medium">{rule.label}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 truncate">
                  → {rule.action}
                </p>
              </div>
            </div>
          ))
        )}
      </div>

      <div className="mt-4 pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground text-center">
          Rules: ADR &gt; 55% | Spike μ+2σ | AGS &gt; 6%
        </p>
      </div>
    </div>
  );
}
