import { TrendingUp, Target, Calendar, AlertTriangle } from 'lucide-react';
import { Metrics } from '@/types/biometric';
import { cn } from '@/lib/utils';

interface KPIRowProps {
  metrics: Metrics;
  meanDailyVolume: number;
}

interface KPICardProps {
  label: string;
  value: string;
  icon: React.ReactNode;
  status: 'normal' | 'warning' | 'danger';
  subtitle?: string;
}

function KPICard({ label, value, icon, status, subtitle }: KPICardProps) {
  const statusStyles = {
    normal: 'border-primary/30 text-primary',
    warning: 'border-warning/30 text-warning',
    danger: 'border-destructive/30 text-destructive',
  };

  const bgStyles = {
    normal: 'bg-primary/10',
    warning: 'bg-warning/10',
    danger: 'bg-destructive/10',
  };

  return (
    <div className={cn(
      "glass-card rounded-lg p-4 border-2 transition-all hover:scale-[1.02]",
      statusStyles[status]
    )}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {label}
          </p>
          <p className={cn("text-3xl font-bold mt-1", statusStyles[status].split(' ')[1])}>
            {value}
          </p>
          {subtitle && (
            <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
          )}
        </div>
        <div className={cn("p-3 rounded-lg", bgStyles[status])}>
          {icon}
        </div>
      </div>
    </div>
  );
}

export function KPIRow({ metrics, meanDailyVolume }: KPIRowProps) {
  const adrStatus = metrics.averageADR > 0.65 ? 'danger' : metrics.averageADR > 0.55 ? 'warning' : 'normal';
  const agsStatus = metrics.accessGapScore > 0.08 ? 'danger' : metrics.accessGapScore > 0.06 ? 'warning' : 'normal';
  const spikeStatus = metrics.anomalyCount > 5 ? 'danger' : metrics.anomalyCount > 3 ? 'warning' : 'normal';

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(0)}K`;
    return num.toString();
  };

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <KPICard
        label="ADR"
        value={`${(metrics.averageADR * 100).toFixed(1)}%`}
        icon={<TrendingUp className="h-5 w-5" />}
        status={adrStatus}
        subtitle="Adult Dominance Ratio"
      />
      <KPICard
        label="AGS"
        value={`${(metrics.accessGapScore * 100).toFixed(2)}%`}
        icon={<Target className="h-5 w-5" />}
        status={agsStatus}
        subtitle="Access Gap Score"
      />
      <KPICard
        label="Mean Daily"
        value={formatNumber(meanDailyVolume)}
        icon={<Calendar className="h-5 w-5" />}
        status="normal"
        subtitle="Average transactions"
      />
      <KPICard
        label="Spike Days"
        value={metrics.anomalyCount.toString()}
        icon={<AlertTriangle className="h-5 w-5" />}
        status={spikeStatus}
        subtitle={`Threshold: ${formatNumber(metrics.spikeThreshold)}`}
      />
    </div>
  );
}
