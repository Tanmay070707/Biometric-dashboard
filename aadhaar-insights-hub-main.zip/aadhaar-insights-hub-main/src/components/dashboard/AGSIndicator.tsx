import { cn } from '@/lib/utils';

interface AGSIndicatorProps {
  value: number;
  threshold?: number;
}

export function AGSIndicator({ value, threshold = 0.06 }: AGSIndicatorProps) {
  const percentage = value * 100;
  const isAboveThreshold = value > threshold;
  const segments = 20;
  const filledSegments = Math.round((percentage / 100) * segments);

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="mb-4">
        <h3 className="text-lg font-semibold">Access Gap Score</h3>
        <p className="text-sm text-muted-foreground">
          Top 10 districts load / total
        </p>
      </div>

      <div className="flex flex-col items-center">
        {/* Segmented progress bar */}
        <div className="flex gap-1 mb-4">
          {Array.from({ length: segments }).map((_, i) => (
            <div
              key={i}
              className={cn(
                "w-3 h-8 rounded-sm transition-all duration-300",
                i < filledSegments 
                  ? isAboveThreshold 
                    ? i > segments * 0.5 ? "bg-destructive" : "bg-warning"
                    : "bg-info"
                  : "bg-muted"
              )}
              style={{
                animationDelay: `${i * 50}ms`,
              }}
            />
          ))}
        </div>

        {/* Value display */}
        <div className="text-center">
          <span className={cn(
            "text-4xl font-bold font-mono",
            isAboveThreshold ? "text-warning" : "text-info"
          )}>
            {percentage.toFixed(1)}%
          </span>
          <p className="text-sm text-muted-foreground mt-1">
            of total load in top 10 districts
          </p>
        </div>

        {/* Status */}
        <div className="mt-4 flex items-center gap-2">
          {isAboveThreshold ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-warning/20 text-warning text-sm">
              <div className="w-2 h-2 rounded-full bg-warning animate-pulse" />
              <span>High concentration - New centers needed</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-success/20 text-success text-sm">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span>Balanced distribution</span>
            </div>
          )}
        </div>

        {/* Threshold marker */}
        <div className="w-full mt-4 relative">
          <div className="h-1 bg-muted rounded-full relative">
            <div 
              className={cn(
                "absolute top-0 h-1 rounded-full transition-all duration-500",
                isAboveThreshold ? "bg-warning" : "bg-info"
              )}
              style={{ width: `${Math.min(percentage, 100)}%` }}
            />
            {/* Threshold line */}
            <div 
              className="absolute top-1/2 -translate-y-1/2 w-0.5 h-4 bg-destructive"
              style={{ left: `${threshold * 100 * (100/20)}%` }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>0%</span>
            <span className="text-destructive">Threshold: {(threshold * 100).toFixed(0)}%</span>
            <span>20%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
