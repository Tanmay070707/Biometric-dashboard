import { ActionRecommendation } from '@/types/biometric';
import { cn } from '@/lib/utils';
import { 
  Eye, 
  Truck, 
  Building2, 
  ArrowRight,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface ActionPanelProps {
  recommendations: ActionRecommendation[];
}

export function ActionPanel({ recommendations }: ActionPanelProps) {
  const [dismissedIds, setDismissedIds] = useState<Set<string>>(new Set());
  const [acknowledgedIds, setAcknowledgedIds] = useState<Set<string>>(new Set());

  const activeRecommendations = recommendations.filter(r => !dismissedIds.has(r.id));

  const getIcon = (type: ActionRecommendation['type']) => {
    switch (type) {
      case 'iris_face':
        return <Eye className="h-5 w-5" />;
      case 'mobile_van':
        return <Truck className="h-5 w-5" />;
      case 'new_center':
        return <Building2 className="h-5 w-5" />;
    }
  };

  const getSeverityStyles = (severity: ActionRecommendation['severity']) => {
    switch (severity) {
      case 'danger':
        return 'action-card-danger';
      case 'warning':
        return 'action-card-warning';
      case 'info':
        return 'action-card-info';
    }
  };

  const getSeverityIcon = (severity: ActionRecommendation['severity']) => {
    switch (severity) {
      case 'danger':
        return <div className="w-2 h-2 rounded-full bg-destructive pulse-dot" />;
      case 'warning':
        return <div className="w-2 h-2 rounded-full bg-warning pulse-dot" />;
      case 'info':
        return <div className="w-2 h-2 rounded-full bg-info" />;
    }
  };

  const handleAcknowledge = (id: string) => {
    setAcknowledgedIds(prev => new Set(prev).add(id));
  };

  const handleDismiss = (id: string) => {
    setDismissedIds(prev => new Set(prev).add(id));
  };

  if (activeRecommendations.length === 0) {
    return (
      <div className="glass-card rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">Action Recommendations</h3>
            <p className="text-sm text-muted-foreground">
              Automated suggestions based on metrics
            </p>
          </div>
        </div>
        <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
          <CheckCircle2 className="h-12 w-12 mb-3 text-success" />
          <p className="text-sm font-medium">All actions addressed!</p>
          <p className="text-xs">No pending recommendations at this time.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Action Recommendations</h3>
          <p className="text-sm text-muted-foreground">
            {activeRecommendations.length} pending actions
          </p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-destructive" />
            <span>Critical</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-warning" />
            <span>Warning</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-info" />
            <span>Suggestion</span>
          </div>
        </div>
      </div>

      <div className="space-y-3 max-h-[400px] overflow-y-auto scrollbar-thin pr-1">
        {activeRecommendations.map((rec) => (
          <div
            key={rec.id}
            className={cn(
              "rounded-lg p-4 bg-card transition-all duration-200",
              getSeverityStyles(rec.severity),
              acknowledgedIds.has(rec.id) && "opacity-60"
            )}
          >
            <div className="flex items-start gap-3">
              <div className={cn(
                "p-2 rounded-lg",
                rec.severity === 'danger' && "bg-destructive/20 text-destructive",
                rec.severity === 'warning' && "bg-warning/20 text-warning",
                rec.severity === 'info' && "bg-info/20 text-info"
              )}>
                {getIcon(rec.type)}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {getSeverityIcon(rec.severity)}
                  <h4 className="font-medium text-sm">{rec.title}</h4>
                </div>
                
                <p className="text-xs text-muted-foreground mb-2">
                  {rec.description}
                </p>
                
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground">
                    📍 {rec.location}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground">
                    {rec.metric}: {(rec.value * 100).toFixed(1)}%
                  </span>
                  <span className="px-2 py-0.5 rounded bg-muted text-muted-foreground">
                    Threshold: {(rec.threshold * 100).toFixed(1)}%
                  </span>
                </div>
                
                <div className="flex items-center gap-2 mt-3">
                  {acknowledgedIds.has(rec.id) ? (
                    <span className="flex items-center gap-1 text-xs text-success">
                      <CheckCircle2 className="h-3 w-3" />
                      Acknowledged
                    </span>
                  ) : (
                    <>
                      <Button
                        size="sm"
                        variant="secondary"
                        className="h-7 text-xs"
                        onClick={() => handleAcknowledge(rec.id)}
                      >
                        Acknowledge
                        <ArrowRight className="h-3 w-3 ml-1" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-xs text-muted-foreground"
                        onClick={() => handleDismiss(rec.id)}
                      >
                        Dismiss
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
