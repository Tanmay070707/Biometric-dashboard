import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface ADRGaugeProps {
  value: number;
  threshold?: number;
}

export function ADRGauge({ value, threshold = 0.55 }: ADRGaugeProps) {
  const percentage = value * 100;
  const isAboveThreshold = value > threshold;
  
  const data = [
    { name: 'ADR', value: percentage },
    { name: 'Remaining', value: 100 - percentage },
  ];

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="mb-2">
        <h3 className="text-lg font-semibold">Adult Dominance Ratio</h3>
        <p className="text-sm text-muted-foreground">
          bio_age_17_ / total transactions
        </p>
      </div>

      <div className="relative h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              startAngle={180}
              endAngle={0}
              innerRadius={60}
              outerRadius={80}
              paddingAngle={0}
              dataKey="value"
            >
              <Cell 
                fill={isAboveThreshold ? 'hsl(38, 92%, 50%)' : 'hsl(173, 80%, 40%)'} 
              />
              <Cell fill="hsl(217, 33%, 22%)" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        
        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-3xl font-bold font-mono ${
            isAboveThreshold ? 'text-warning' : 'text-primary'
          }`}>
            {percentage.toFixed(1)}%
          </span>
          <span className="text-xs text-muted-foreground">ADR</span>
        </div>
      </div>

      {/* Threshold indicator */}
      <div className="flex items-center justify-center gap-4 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-3 h-0.5 bg-muted-foreground" />
          <span className="text-muted-foreground">Threshold: {(threshold * 100).toFixed(0)}%</span>
        </div>
        {isAboveThreshold && (
          <span className="px-2 py-0.5 rounded bg-warning/20 text-warning font-medium">
            ⚠️ Above Limit
          </span>
        )}
      </div>
    </div>
  );
}
