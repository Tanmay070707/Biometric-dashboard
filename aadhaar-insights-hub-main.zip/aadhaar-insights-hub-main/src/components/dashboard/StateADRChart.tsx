import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  ReferenceLine
} from 'recharts';
import { StateAggregate } from '@/types/biometric';

interface StateADRChartProps {
  data: StateAggregate[];
}

export function StateADRChart({ data }: StateADRChartProps) {
  const chartData = data.slice(0, 10).map(state => ({
    name: state.state.length > 8 ? state.state.slice(0, 8) + '...' : state.state,
    fullName: state.state,
    adr: +(state.adr * 100).toFixed(1),
    total: state.total,
  }));

  const getBarColor = (adr: number) => {
    if (adr > 65) return 'hsl(0, 84%, 60%)';
    if (adr > 55) return 'hsl(38, 92%, 50%)';
    return 'hsl(173, 80%, 40%)';
  };

  return (
    <div className="glass-card rounded-lg p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">State-wise ADR</h3>
          <p className="text-sm text-muted-foreground">
            Adult Dominance Ratio by State (Top 10)
          </p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-muted-foreground">&lt;55%</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-warning" />
            <span className="text-muted-foreground">55-65%</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-destructive" />
            <span className="text-muted-foreground">&gt;65%</span>
          </div>
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={chartData} margin={{ top: 10, right: 20, bottom: 20, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(217, 33%, 22%)" vertical={false} />
          <XAxis 
            dataKey="name" 
            stroke="hsl(215, 20%, 65%)"
            fontSize={10}
            tickLine={false}
            axisLine={false}
            angle={-35}
            textAnchor="end"
            height={60}
          />
          <YAxis 
            stroke="hsl(215, 20%, 65%)"
            fontSize={11}
            tickLine={false}
            axisLine={false}
            domain={[0, 100]}
            tickFormatter={(v) => `${v}%`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'hsl(222, 47%, 14%)',
              border: '1px solid hsl(217, 33%, 22%)',
              borderRadius: '8px',
              fontSize: '12px',
            }}
            labelStyle={{ color: 'hsl(210, 40%, 98%)' }}
            formatter={(value: number) => [`${value}%`, 'ADR']}
            labelFormatter={(label, payload) => payload[0]?.payload?.fullName || label}
          />
          <ReferenceLine 
            y={55} 
            stroke="hsl(38, 92%, 50%)" 
            strokeDasharray="5 5"
            label={{
              value: '55% Threshold',
              position: 'right',
              fill: 'hsl(38, 92%, 50%)',
              fontSize: 10,
            }}
          />
          <Bar dataKey="adr" radius={[4, 4, 0, 0]}>
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getBarColor(entry.adr)} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
