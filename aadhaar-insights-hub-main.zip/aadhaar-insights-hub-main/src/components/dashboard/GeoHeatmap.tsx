import { useState } from 'react';
import { StateAggregate, DistrictAggregate } from '@/types/biometric';
import { cn } from '@/lib/utils';

interface GeoHeatmapProps {
  stateData: StateAggregate[];
  districtData: DistrictAggregate[];
}

type ViewMode = 'total' | 'adr' | 'youth';

export function GeoHeatmap({ stateData, districtData }: GeoHeatmapProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('total');
  const [selectedState, setSelectedState] = useState<string | null>(null);

  const maxTotal = Math.max(...stateData.map(d => d.total));
  const maxADR = Math.max(...stateData.map(d => d.adr));

  const getIntensity = (state: StateAggregate): string => {
    let ratio: number;
    switch (viewMode) {
      case 'adr':
        ratio = state.adr / maxADR;
        if (state.adr > 0.65) return 'bg-destructive';
        if (state.adr > 0.55) return 'bg-warning';
        return ratio > 0.5 ? 'bg-primary/80' : 'bg-primary/50';
      case 'youth':
        ratio = state.bio_age_5_17 / Math.max(...stateData.map(d => d.bio_age_5_17));
        break;
      default:
        ratio = state.total / maxTotal;
    }
    if (ratio > 0.8) return 'bg-primary';
    if (ratio > 0.6) return 'bg-primary/80';
    if (ratio > 0.4) return 'bg-primary/60';
    if (ratio > 0.2) return 'bg-primary/40';
    return 'bg-primary/20';
  };

  const formatValue = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toString();
  };

  const filteredDistricts = selectedState 
    ? districtData.filter(d => d.state === selectedState).slice(0, 15)
    : districtData.slice(0, 15);

  return (
    <div className="space-y-6">
      {/* View Mode Selector */}
      <div className="glass-card rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">State Intelligence Map</h3>
            <p className="text-sm text-muted-foreground">
              Click a state to see district breakdown
            </p>
          </div>
          <div className="flex gap-2">
            {(['total', 'adr', 'youth'] as ViewMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => setViewMode(mode)}
                className={cn(
                  "px-3 py-1.5 text-xs font-medium rounded-lg transition-all",
                  viewMode === mode 
                    ? "bg-primary text-primary-foreground" 
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                )}
              >
                {mode === 'total' ? 'Volume' : mode === 'adr' ? 'ADR' : 'Youth'}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {stateData.map((state) => (
            <div
              key={state.state}
              onClick={() => setSelectedState(selectedState === state.state ? null : state.state)}
              className={cn(
                "relative rounded-lg p-4 cursor-pointer group transition-all",
                getIntensity(state),
                selectedState === state.state && "ring-2 ring-foreground ring-offset-2 ring-offset-background"
              )}
            >
              <div className="relative z-10">
                <p className="text-xs font-medium text-primary-foreground/90 truncate">
                  {state.state}
                </p>
                <p className="text-lg font-bold text-primary-foreground mt-1">
                  {viewMode === 'adr' 
                    ? `${(state.adr * 100).toFixed(1)}%`
                    : viewMode === 'youth'
                      ? formatValue(state.bio_age_5_17)
                      : formatValue(state.total)
                  }
                </p>
                <p className="text-xs text-primary-foreground/70">
                  {viewMode === 'total' && `ADR: ${(state.adr * 100).toFixed(1)}%`}
                  {viewMode === 'adr' && `Vol: ${formatValue(state.total)}`}
                  {viewMode === 'youth' && `${state.districtCount} districts`}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-4 mt-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <span>Low</span>
            <div className="flex gap-1">
              <div className="w-6 h-3 rounded bg-primary/20" />
              <div className="w-6 h-3 rounded bg-primary/40" />
              <div className="w-6 h-3 rounded bg-primary/60" />
              <div className="w-6 h-3 rounded bg-primary/80" />
              <div className="w-6 h-3 rounded bg-primary" />
            </div>
            <span>High</span>
          </div>
          {viewMode === 'adr' && (
            <>
              <span className="text-muted-foreground/50">|</span>
              <div className="flex items-center gap-2">
                <div className="w-4 h-3 rounded bg-warning" />
                <span>&gt;55%</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-3 rounded bg-destructive" />
                <span>&gt;65%</span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* District Breakdown */}
      <div className="glass-card rounded-lg p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold">
              {selectedState ? `${selectedState} Districts` : 'Top Districts'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {selectedState ? 'Click state again to deselect' : 'Select a state to filter'}
            </p>
          </div>
          {selectedState && (
            <button
              onClick={() => setSelectedState(null)}
              className="text-xs text-primary hover:underline"
            >
              Clear Selection
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredDistricts.map((district, index) => {
            const districtMaxLoad = Math.max(...filteredDistricts.map(d => d.total));
            const loadPercentage = (district.total / districtMaxLoad) * 100;
            
            return (
              <div 
                key={`${district.state}-${district.district}`}
                className="p-3 rounded-lg bg-muted/50 border border-border hover:border-primary/30 transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-muted-foreground">
                      #{index + 1}
                    </span>
                    <span className="text-sm font-medium truncate max-w-[120px]">
                      {district.district}
                    </span>
                  </div>
                  <span className={cn(
                    "text-xs font-medium px-2 py-0.5 rounded-full",
                    district.adr > 0.65 ? "bg-destructive/20 text-destructive" :
                    district.adr > 0.55 ? "bg-warning/20 text-warning" :
                    "bg-primary/20 text-primary"
                  )}>
                    {(district.adr * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-background rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${loadPercentage}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground w-12 text-right">
                    {formatValue(district.total)}
                  </span>
                </div>
                {!selectedState && (
                  <p className="text-xs text-muted-foreground mt-1 truncate">
                    {district.state}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
