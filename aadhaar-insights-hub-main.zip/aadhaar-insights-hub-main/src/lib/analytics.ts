import { 
  BiometricRecord, 
  DailyAggregate, 
  StateAggregate, 
  DistrictAggregate, 
  Metrics,
  ActionRecommendation 
} from '@/types/biometric';

// Calculate mean and standard deviation
function calculateStats(values: number[]): { mean: number; std: number } {
  const n = values.length;
  if (n === 0) return { mean: 0, std: 0 };
  
  const mean = values.reduce((sum, val) => sum + val, 0) / n;
  const squaredDiffs = values.map(val => Math.pow(val - mean, 2));
  const variance = squaredDiffs.reduce((sum, val) => sum + val, 0) / n;
  const std = Math.sqrt(variance);
  
  return { mean, std };
}

// Aggregate data by date
export function aggregateByDate(data: BiometricRecord[]): DailyAggregate[] {
  const dateMap = new Map<string, { total: number; bio_age_5_17: number; bio_age_17_: number }>();
  
  data.forEach(record => {
    const existing = dateMap.get(record.date) || { total: 0, bio_age_5_17: 0, bio_age_17_: 0 };
    dateMap.set(record.date, {
      total: existing.total + record.bio_age_5_17 + record.bio_age_17_,
      bio_age_5_17: existing.bio_age_5_17 + record.bio_age_5_17,
      bio_age_17_: existing.bio_age_17_ + record.bio_age_17_,
    });
  });
  
  const entries = Array.from(dateMap.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  const totals = entries.map(([, v]) => v.total);
  const { mean, std } = calculateStats(totals);
  const threshold = mean + 2 * std;
  
  return entries.map(([date, values]) => ({
    date,
    total: values.total,
    bio_age_5_17: values.bio_age_5_17,
    bio_age_17_: values.bio_age_17_,
    isAnomaly: values.total > threshold,
    adr: values.total > 0 ? values.bio_age_17_ / values.total : 0,
  }));
}

// Aggregate data by state
export function aggregateByState(data: BiometricRecord[]): StateAggregate[] {
  const stateMap = new Map<string, { 
    total: number; 
    bio_age_5_17: number; 
    bio_age_17_: number;
    districts: Set<string>;
  }>();
  
  data.forEach(record => {
    const existing = stateMap.get(record.state) || { 
      total: 0, 
      bio_age_5_17: 0, 
      bio_age_17_: 0,
      districts: new Set<string>(),
    };
    existing.districts.add(record.district);
    stateMap.set(record.state, {
      total: existing.total + record.bio_age_5_17 + record.bio_age_17_,
      bio_age_5_17: existing.bio_age_5_17 + record.bio_age_5_17,
      bio_age_17_: existing.bio_age_17_ + record.bio_age_17_,
      districts: existing.districts,
    });
  });
  
  return Array.from(stateMap.entries())
    .map(([state, values]) => ({
      state,
      total: values.total,
      bio_age_5_17: values.bio_age_5_17,
      bio_age_17_: values.bio_age_17_,
      adr: values.total > 0 ? values.bio_age_17_ / values.total : 0,
      districtCount: values.districts.size,
    }))
    .sort((a, b) => b.total - a.total);
}

// Aggregate data by district
export function aggregateByDistrict(data: BiometricRecord[]): DistrictAggregate[] {
  const districtMap = new Map<string, { 
    state: string;
    total: number; 
    bio_age_5_17: number; 
    bio_age_17_: number;
  }>();
  
  data.forEach(record => {
    const key = `${record.state}-${record.district}`;
    const existing = districtMap.get(key) || { 
      state: record.state,
      total: 0, 
      bio_age_5_17: 0, 
      bio_age_17_: 0,
    };
    districtMap.set(key, {
      state: record.state,
      total: existing.total + record.bio_age_5_17 + record.bio_age_17_,
      bio_age_5_17: existing.bio_age_5_17 + record.bio_age_5_17,
      bio_age_17_: existing.bio_age_17_ + record.bio_age_17_,
    });
  });
  
  return Array.from(districtMap.entries())
    .map(([key, values]) => ({
      district: key.split('-')[1],
      state: values.state,
      total: values.total,
      bio_age_5_17: values.bio_age_5_17,
      bio_age_17_: values.bio_age_17_,
      adr: values.total > 0 ? values.bio_age_17_ / values.total : 0,
    }))
    .sort((a, b) => b.total - a.total);
}

// Calculate overall metrics
export function calculateMetrics(data: BiometricRecord[]): Metrics {
  const daily = aggregateByDate(data);
  const districts = aggregateByDistrict(data);
  
  const totalTransactions = daily.reduce((sum, d) => sum + d.total, 0);
  const totalAdult = daily.reduce((sum, d) => sum + d.bio_age_17_, 0);
  const averageADR = totalTransactions > 0 ? totalAdult / totalTransactions : 0;
  
  // Access Gap Score: Top 10 districts' load / total
  const top10Load = districts.slice(0, 10).reduce((sum, d) => sum + d.total, 0);
  const accessGapScore = totalTransactions > 0 ? top10Load / totalTransactions : 0;
  
  const anomalyCount = daily.filter(d => d.isAnomaly).length;
  
  const totals = daily.map(d => d.total);
  const { mean, std } = calculateStats(totals);
  
  return {
    totalTransactions,
    averageADR,
    accessGapScore,
    anomalyCount,
    spikeThreshold: mean + 2 * std,
  };
}

// Generate action recommendations
export function generateRecommendations(data: BiometricRecord[]): ActionRecommendation[] {
  const daily = aggregateByDate(data);
  const districts = aggregateByDistrict(data);
  const states = aggregateByState(data);
  const metrics = calculateMetrics(data);
  
  const recommendations: ActionRecommendation[] = [];
  
  // Check ADR > 0.55 for states
  states.forEach(state => {
    if (state.adr > 0.55) {
      recommendations.push({
        id: `iris-${state.state}`,
        type: 'iris_face',
        severity: state.adr > 0.65 ? 'danger' : 'warning',
        title: 'Deploy IRIS/FACE Counters',
        description: `High Adult Dominance Ratio detected. Recommend deploying additional IRIS and FACE biometric counters to handle adult enrollment volume.`,
        location: state.state,
        metric: 'ADR',
        value: state.adr,
        threshold: 0.55,
      });
    }
  });
  
  // Check for spike days
  const recentAnomalies = daily.filter(d => d.isAnomaly).slice(-5);
  recentAnomalies.forEach(anomaly => {
    recommendations.push({
      id: `spike-${anomaly.date}`,
      type: 'mobile_van',
      severity: 'danger',
      title: 'Deploy Mobile Van & Appointments',
      description: `Anomaly spike detected on ${anomaly.date}. Deploy mobile vans and enable appointment-based scheduling to manage surge.`,
      location: 'All High-Load Districts',
      metric: 'Daily Volume',
      value: anomaly.total,
      threshold: metrics.spikeThreshold,
    });
  });
  
  // Check AGS > 0.06 (top districts overloaded)
  if (metrics.accessGapScore > 0.06) {
    const topDistricts = districts.slice(0, 5);
    topDistricts.forEach(district => {
      recommendations.push({
        id: `center-${district.state}-${district.district}`,
        type: 'new_center',
        severity: 'info',
        title: 'Suggest New Enrollment Center',
        description: `High concentration of enrollment load. Consider opening new enrollment centers to distribute access more evenly.`,
        location: `${district.district}, ${district.state}`,
        metric: 'AGS Contribution',
        value: district.total / metrics.totalTransactions,
        threshold: 0.06,
      });
    });
  }
  
  return recommendations.slice(0, 10);
}
