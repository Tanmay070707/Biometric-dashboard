import { BiometricRecord } from '@/types/biometric';

const states = [
  'Maharashtra', 'Uttar Pradesh', 'Tamil Nadu', 'Karnataka', 'Gujarat',
  'Rajasthan', 'West Bengal', 'Madhya Pradesh', 'Bihar', 'Andhra Pradesh'
];

const districtsByState: Record<string, string[]> = {
  'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik'],
  'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Varanasi', 'Agra', 'Prayagraj'],
  'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Salem', 'Tiruchirappalli'],
  'Karnataka': ['Bengaluru', 'Mysuru', 'Hubli', 'Mangaluru', 'Belgaum'],
  'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar'],
  'Rajasthan': ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Ajmer'],
  'West Bengal': ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri'],
  'Madhya Pradesh': ['Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain'],
  'Bihar': ['Patna', 'Gaya', 'Muzaffarpur', 'Bhagalpur', 'Darbhanga'],
  'Andhra Pradesh': ['Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Tirupati'],
};

function generateRandomValue(min: number, max: number, spike = false): number {
  const base = Math.floor(Math.random() * (max - min + 1)) + min;
  return spike ? base * 2.5 : base;
}

export function generateMockData(): BiometricRecord[] {
  const records: BiometricRecord[] = [];
  const startDate = new Date('2024-12-01');
  const endDate = new Date('2025-01-15');
  
  // Create spike days (anomalies)
  const spikeDays = [5, 12, 20, 28, 35, 42];
  
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const dayIndex = Math.floor((d.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const isSpike = spikeDays.includes(dayIndex);
    
    for (const state of states) {
      const districts = districtsByState[state];
      for (const district of districts) {
        // Higher adult ratio in urban districts
        const isUrban = ['Mumbai', 'Chennai', 'Bengaluru', 'Kolkata', 'Ahmedabad'].includes(district);
        const adultBias = isUrban ? 1.8 : 1.2;
        
        const bio_age_5_17 = generateRandomValue(100, 500, isSpike);
        const bio_age_17_ = Math.floor(generateRandomValue(200, 800, isSpike) * adultBias);
        
        records.push({
          date: d.toISOString().split('T')[0],
          state,
          district,
          bio_age_5_17,
          bio_age_17_,
        });
      }
    }
  }
  
  return records;
}

export const mockData = generateMockData();
