export interface BiometricRecord {
  date: string;
  state: string;
  district: string;
  bio_age_5_17: number;
  bio_age_17_: number;
}

export interface DailyAggregate {
  date: string;
  total: number;
  bio_age_5_17: number;
  bio_age_17_: number;
  isAnomaly: boolean;
  adr: number;
}

export interface StateAggregate {
  state: string;
  total: number;
  bio_age_5_17: number;
  bio_age_17_: number;
  adr: number;
  districtCount: number;
}

export interface DistrictAggregate {
  state: string;
  district: string;
  total: number;
  bio_age_5_17: number;
  bio_age_17_: number;
  adr: number;
}

export interface Metrics {
  totalTransactions: number;
  averageADR: number;
  accessGapScore: number;
  anomalyCount: number;
  spikeThreshold: number;
}

export interface ActionRecommendation {
  id: string;
  type: 'iris_face' | 'mobile_van' | 'new_center';
  severity: 'warning' | 'danger' | 'info';
  title: string;
  description: string;
  location: string;
  metric: string;
  value: number;
  threshold: number;
}
